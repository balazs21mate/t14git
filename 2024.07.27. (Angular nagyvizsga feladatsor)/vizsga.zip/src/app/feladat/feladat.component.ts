import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

  vizsgalandoSzam!: number;


  primTomb: string[] = [];

  EredmenyMentes(): void {
    if (PrimE(this.vizsgalandoSzam)) {
      this.primTomb.push("A(z) " + this.vizsgalandoSzam + " prím");
    }
    else {
      this.primTomb.push("A(z) " + this.vizsgalandoSzam + " NEM prím");
    }
  }
}

export function PrimE(vizsgalandoSzam: number): boolean {
  let osztokListaja: number[] = [];

  for (let i = 1; i <= vizsgalandoSzam; i++) {
    if (vizsgalandoSzam % i == 0) {
      osztokListaja.push(i);
    }
  }

  if (osztokListaja.length == 2) {
    return true;
  } else {
    return false;
  }
}