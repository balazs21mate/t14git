import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrl: './feladat.component.css'
})
export class FeladatComponent {

  vizsgalandoSzam!: number;


  primTomb: string[] = [];

  PrimE(vizsgalandoSzam: number): boolean {
    let osztokListaja: number[] = [];

    for (let i = 1; i <= vizsgalandoSzam; i++) {
      if (vizsgalandoSzam % i == 0) {
        osztokListaja.push(i);
      }
    }

    if (osztokListaja.length == 2) {
      return true;
    } else {
      return false;
    }
  }

  EredmenyMentes(): void {
    if (this.PrimE(this.vizsgalandoSzam)) {
      this.primTomb.push("A(z) " + this.vizsgalandoSzam + " prím");
    }
    else {
      this.primTomb.push("A(z) " + this.vizsgalandoSzam + " NEM prím");
    }
  }

  get EredmenyKiir(): string {
    if (this.PrimE(this.vizsgalandoSzam)) {
      return "prím";
    } else {
      return "NEM prím";
    }
  }
}