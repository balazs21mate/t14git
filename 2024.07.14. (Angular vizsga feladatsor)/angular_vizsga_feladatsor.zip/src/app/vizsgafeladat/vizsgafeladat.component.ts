import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrl: './vizsgafeladat.component.css'
})
export class VizsgafeladatComponent {
  htmlModul!: number;
  bootstrapModul!: number;
  javaScriptModul!: number;
  typeScriptModul!: number;
  angularModul!: number;
  serverModul!: number;

  eredmeny: number = 0;
  ertekelesLista: string[] = [];



  EredmenyMentes(): void {
    if (this.htmlModul && this.bootstrapModul && this.javaScriptModul && this.typeScriptModul && this.angularModul && this.serverModul) {
      this.eredmeny = this.htmlModul + this.bootstrapModul + this.javaScriptModul + this.typeScriptModul + this.angularModul + this.serverModul
      if (this.eredmeny < 50) {
        this.ertekelesLista.push(`Sikertelen vizsga, szerzett pont: ${this.eredmeny}`);
      } else if (this.eredmeny > 51 && this.eredmeny < 60) {
        this.ertekelesLista.push(`Sikeres vizsga (2-es), szerzett pont: ${this.eredmeny}`);
      } else if (this.eredmeny > 59 && this.eredmeny < 70) {
        this.ertekelesLista.push(`Sikeres vizsga (3-es), szerzett pont: ${this.eredmeny}`);
      } else if (this.eredmeny > 69 && this.eredmeny < 80) {
        this.ertekelesLista.push(`Sikeres vizsga (4-es), szerzett pont: ${this.eredmeny}`);
      } else if (this.eredmeny > 79) {
        this.ertekelesLista.push(`Sikeres vizsga (5-es), szerzett pont: ${this.eredmeny}`);
      }
    } else {
      alert("Az összes mező kitöltése kötelező!");
    }
  }
}
