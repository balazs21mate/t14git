import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TablazatComponent } from './tablazat/tablazat.component';

const routes: Routes = [
  { path: "tablazat", component: TablazatComponent },
  { path: "", redirectTo: "/tablazat", pathMatch: "full" },
  { path: "**", component: TablazatComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
